Version 0.02.03
Changelogs
-Semanticness Improves
-More under the hood improvements
-Dark mode are more darker