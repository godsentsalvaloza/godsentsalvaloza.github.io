Version 0.02.02
Changelogs
Dark theme added
